#!/usr/bin/perl -w

use strict;
use Carp qw();
use MSL::Network;
use MSL::Master;
use MSL::OD;
use MSL::Incident;
use LinearRoad;
use CarReporter;
use Data::Dumper;
use Getopt::Long;
use Pod::Usage;

############################################################
# Bugs
# - Track ramps vs. roads
# - Use hash constructors for links.
# 

$SIG{__DIE__} = sub {Carp::confess(@_);};

############################################################
# PARAMETERS

# Everything directory.
my $dir;

#my $commondir = "$ENV{HOME}/MITSIMLab/Common";
my $commondir = "$ENV{MITSIMDIR}/Common";

# Segments per road. Not the same as a MITSIMLab segment
my $segments = 100;
# Lanes in the relevant direction.
my $lanes = 3;
# Length of each segment, in feet.
my $segment_length = 5280;                
# Offset between start of segment and end of onramp. Feet.
# Also offset between start of offramp and end of segment.
my $ramp_offset = 1000;
# Offset in the y axis for offramp end and onramp start.
my $ramp_yoffset = 1000;

my %network_parameters = (title => "Linear Road Network",
			  # Miles per hour.
			  speed_limit => 55,
			  free_speed => 70,
			  ramp_speed_limit => 25,
			  ramp_free_speed => 35);

# Cars per hour from each entrance.
my $cars_per_hour = 500;

my $endtime = "3:00:00";
#my $endtime = "0:30:00";
my $dont_run_network = 0;
my $just_process_data = 0;

############################################################
# Command line options.

my ($man, $help) = (0,0);
GetOptions('help|?' => \$help, 'man' => \$man,
	   'dont-run' => \$dont_run_network,
	   'just-process=i' => \$just_process_data,
	   'dir=s' => \$dir,
	   'segments=i' => \$segments,
	   'lanes=i' => \$lanes,
	   'segment-length=i' => \$segment_length,
	   'cars-per-hour=i' => \$cars_per_hour,
	   'endtime=s' => \$endtime) or pod2usage(2);
pod2usage(1) if $help;
pod2usage(-exitstatus => 0, -verbose => 2) if $man;

unless ($dir) {
  $dir = "/home/oracle/combined/trafficsim";
  print "Defaulting to $dir for everything.\n";
}  

unless (-d $dir) {
  print "Creating $dir\n";
  mkdir $dir or die "Could not create $dir: $!";
}



=head1 NAME

linear-road.pl - Create a road network, run it in MITSIMLab, and
rototil the output for the linear road benchmark.

=head1 OPTIONS

=over 8

=item B<--help>

Prints a brief help message and exits

=item B<--man>

Prints the manpage and exits.

=item B<--dir=DIRECTORY>

Output the road network to a file in DIRECTORY, and put the output
files there.

=item B<--segments=NUM>

Create a road network with NUM segments

=item B<--lanes=NUM>

Number of lanes on the main highway.

=item B<--segment-length=NUM>

Length of each highway segment in feet.

=item B<--cars-per-hour=NUM>

Put NUM cars per hour between each origin and destination.

=item B<--endtime=TIME>

The end time of th simulation. Specified as a string, like "1:12:34"
which is one hour, twelve minutes and thirty-four seconds.

=item B<--dont-run>

Don't run the network, just output the configuration files.

=item B<--just-process>

Don't run the network, just process the simulator output that is
already there.

=back

=cut

############################################################
# Write the Master file.

my $m = new MSL::Master(endtime => $endtime,
			dir => $dir,
			common => $commondir);
$m->write();

############################################################
# BUILD THE ROAD NETWORK

my $lr = new LinearRoad($segments, $segment_length,
			$ramp_offset, $lanes,
			%network_parameters);

unless ($just_process_data) {
  # Print the road network to file.
  open NETWORK, '>'.$dir.'/network.dat' or die;
  my $wf = sub {print NETWORK @_};
  $lr->network()->writeNetwork($wf);
  close NETWORK;
} 


############################################################
# Origins and Destinations.
{
  my $od = new MSL::OD();
  $od->uniform_entry_normal_exit($lr, $cars_per_hour);
  unless ($just_process_data) {
    $od->write($dir.'/od.dat');
  }
}

############################################################
# Incidents

my $incident = new MSL::Incident($lr->network(), $lr->network()->{speed_limit}, $m->{starttime}, $m->{endtime});
my @incidents;

unless ($just_process_data) {
   @incidents = $incident->write($dir.'/incident.dat'); 
}

############################################################
# Run the program.
if ($dont_run_network) {
  # Exit.
  print STDERR "Not running the network. Done creating it.\n";
  exit(0);
}
unless ($just_process_data) {
  chdir $dir;
  # Start pvmd
  system("pvm << /dev/null");
  system("mitsim -m master.mitsim");
  system("echo halt | pvm");
  print "\nDone halting pvm\n";
}

############################################################
# Now rototill the trajectory file to create our own output.
open TRAG, "cat $dir/trajectory.out|" or die "Couldn't open $dir/trajectory.out: $!";

my ($line, $time);
my $state = 0;
print "Creating a car reporter.\n";
my $cr = CarReporter->new($lr->network,
			  $dir."/cardatapoints.out",
			  30,
                          @incidents);

print "Starting to loop over trajectory\n";
while ($line = <TRAG>) {
  if ($line =~ m/^\s*\#.*$/ ||
      $line =~ m/^\s*$/) {
    next;
  }
  $line =~ s/\#.*$//;
  if ($state == 0) {
    # Find a number, this will be a number of seconds and will
    # introduce a {'d block of readings.
    if ($line =~ m/^(\d+) \{$/) {
      $time = $1;
      $state = 1;
    } else {
      die "Line $. ($line) is malformed in state 0";
    }
  } elsif ($state == 1) {
    # Either a } or a row of 4 numbers.
    if ($line =~ m/^\}$/) {
      $state = 0;
    } elsif ($line =~ m/^ (\d+) (\d+) ([0-9.]+) ([0-9.]+)$/) {
      my ($carid, $laneid, $x, $y) = ($1, $2, $3, $4);
      $cr->datapoint($time, $carid, $laneid, $x, $y);
    } else {
      die "Line $. ($line) is malformed in state 1";
    }
  } else {
    die "Invalid state.";
  }
}

$cr->accidentCars();

#print "cr: ", Dumper($cr), "\n";

close TRAG;
