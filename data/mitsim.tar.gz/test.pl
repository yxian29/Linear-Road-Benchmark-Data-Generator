#!/usr/bin/perl -w
use DBI;

use FileHandle;

my $dbh = DBI->connect("DBI:PgPP:db4", "linear", "linear")
           or die "Couldn't connect to database: ". DBI->errstr;

$dbh->disconnect;
