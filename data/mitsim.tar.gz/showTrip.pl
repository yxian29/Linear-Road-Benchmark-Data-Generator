#!/usr/bin/perl -w

@ARGV == 1 or die ("Usage: showTrip.pl [CAR ID] < [INPUT FILE]");

my $carid = $ARGV[0];



my $lseg = -1;
my $numtollalerts = 0;

print "(Reading from STDIN...)\n";

print "\n\tCAR ID $carid\n\n";
print "SEC\tMIN\tSEG\tPOS\tLANE\n";
print "---\t---\t---\t---\t----\n";
while (<STDIN>) {

    my ($type,$time,$car,$lane,$pos) = /^(\d),(\d+),(\d+),-?\d+,-?\d+,(-?\d+),-?\d+,-?\d+,(-?\d+),/ or die ("invalid data row");
    $type == 0 or next;
    $car == $carid or next;

    my $starprinted = 0;

    my $seg = int($pos / 5280);
    print $time; # seconds
    print "\t ";
    print int(($time / 60)) + 1; # minute
    print "\t";
    print $seg; #segment
    if ($lseg != $seg and $lane != 4) { ++$numtollalerts; print " *"; $starprinted = 1; }

    $lseg = $seg;
    print "\t";
    print $pos; # position
    print "\t  ";
    print $lane; # lane

    print " [$numtollalerts]" if $starprinted == 1;
    print "\n";

    # Done if lane is 4 (car exits!)
    if ($lane == 4) { print "\nToll alerts for car $carid : $numtollalerts\n"; exit; }

}

# If here, file ended, car didnt exit. print out info
print "\nToll alerts for car $carid : $numtollalerts\n";
