#!/usr/bin/perl -w

use strict;
use Math::Random qw(random_normal);

=head1 distribute

Return an array with $n buckets, distributing $k balls into the $n
buckets with a normal distribution. Average value $n/2, standard
deviation $n/4.

=cut

sub distribute {
    my ($n, $k) = @_;
    my $mean = ($n/2);
    my $std_dev = ($n/4);

    my @buckets;
    foreach my $bucket (random_normal($k, $mean, $std_dev)) {
	if ($bucket < 0 || $bucket >= $n) {
	    #print "outlier: $bucket\n";
	} else {
	    # Put a ball in this bucket.
	    @buckets[$bucket]++;
	}
    }
    return map {$_ ? $_ : 0} @buckets;
}

my $line;
print "Number of buckets:\n";
$line = <STDIN>;
chomp($line);
my $buckets = $line;
print "Number of balls:\n";
$line = <STDIN>;
chomp($line);
my $balls = $line;

my @locations = distribute($buckets, $balls);
print join(":", @locations), "\n";
my $total = 0;
foreach (@locations) {
    $total += $_;
}
print "total: $total\n";





    
