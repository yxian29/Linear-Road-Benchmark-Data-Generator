#!/usr/bin/perl -w

@ARGV == 1 or die("to generate toll-stats, give me xway");

my $xway = $ARGV[0];

open(OUT, ">xway$xway.historical-stats");

for (my $day = 1; $day <= 69; ++$day) {
    for (my $min = 1; $min <= 1440; ++$min) {
	for (my $dir = 0; $dir <= 1; ++$dir) {
	    for (my $seg = 0; $seg <= 99; ++$seg) {
		my $lav = int(rand(99));
		my $cnt = int(rand(150));
		my $toll;
		if ($lav >= 40 || $cnt <= 50) {
		    $toll = 0;
		} else {
		    $toll = 2 * ($cnt - 50) * ($cnt - 50);
		}
		# (day, min, xway, dir, seg, lav, cnt, toll)
		print OUT "$day,$min,$xway,$dir,$seg,$lav,$cnt,$toll\n";
	    }
	}
    }
}
