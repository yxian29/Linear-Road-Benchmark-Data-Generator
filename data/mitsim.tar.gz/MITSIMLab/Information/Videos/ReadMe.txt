The attached codec (tscc) must be installed in order to view the video AVI files. For further details see www.techsmith.com

