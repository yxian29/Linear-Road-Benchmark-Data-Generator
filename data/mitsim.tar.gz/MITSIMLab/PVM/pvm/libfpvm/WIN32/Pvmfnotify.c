
/* $Id: Pvmfnotify.c,v 1.1 1997/06/27 16:28:40 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\include\pvm3.h"
#include "..\..\src\pvmwin.h"
#else 
#include "pvm3.h"
#endif

#include "pvm_consts.h"

void /*__stdcall*/ __fortran
PVMFNOTIFY (about, msgtag, ntid, tids, info)
int *about, *ntid, *tids, *msgtag, *info;
{
	*info = pvm_notify(*about, *msgtag, *ntid, tids);
}

