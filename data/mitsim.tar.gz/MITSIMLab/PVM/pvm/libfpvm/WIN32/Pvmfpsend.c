
/* $Id: Pvmfpsend.c,v 1.1 1997/06/27 16:29:59 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\include\pvm3.h"
#include "..\..\src\pvmwin.h"
#else 
#include "pvm3.h"
#endif

#include "pvm_consts.h"

void /*__stdcall*/ __fortran
PVMFPSEND (tid, msgtag, buf,buf_len, len, dt, info)
   int *tid, *msgtag, *len, *dt, *info;
   char *buf;int buf_len;
{
   *info = pvm_psend(*tid, *msgtag, buf, *len, *dt);
}

