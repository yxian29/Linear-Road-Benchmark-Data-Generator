
/* $Id: Pvmftrecv.c,v 1.1 1997/06/27 16:34:42 pvmsrc Exp $ */

#include <sys/types.h>

#ifdef WIN32
#include "..\..\src\pvmwin.h"
#include <time.h>
#else 
#include <sys/time.h>
#endif
#include "pvm3.h"

#include "pvm_consts.h"

void  __fortran
PVMFTRECV (tid, msgtag, sec, usec, info)
int *tid, *msgtag, *sec, *usec, *info;
{
   struct timeval t;

   t.tv_sec = *sec;
   t.tv_usec = *usec;
   *info = pvm_trecv(*tid, *msgtag, (*sec == -1 ? (struct timeval *)0 : &t));
}

