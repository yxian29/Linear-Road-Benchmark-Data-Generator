
/* $Id: Pvmfrecvinfo.c,v 1.1 1997/06/27 16:30:32 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\src\pvmwin.h"
#endif
#include "pvm3.h"
#include "pvm_consts.h"

void __fortran
PVMFRECVINFO (name_ptr, mbx_index, flags, bufid, name_len)
char * name_ptr; int name_len;
int *mbx_index, *flags, *bufid;
{

	char tname[MAX_MBOX_NAME + 1];

	/*
	*  Copy the mailbox name to make sure there is
	* a NUL at the end.
	*/
	if (ftocstr(tname, sizeof(tname), name_ptr, name_len)) {
		*bufid = PvmBadParam;
		return;
	}

	*bufid = pvm_recvinfo(tname, *mbx_index, *flags);
}

