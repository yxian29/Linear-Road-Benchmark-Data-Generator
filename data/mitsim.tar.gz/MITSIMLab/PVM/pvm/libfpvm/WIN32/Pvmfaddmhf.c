
/* $Id: Pvmfaddmhf.c,v 1.1 1997/06/27 16:13:47 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\src\pvmwin.h"
#endif
#include "pvm3.h"
#include "pvm_consts.h"

void __fortran
PVMFADDMHF (src, tag, ctx, mid, foo, info)

int (*foo)();
int *src, *tag, *ctx, *mid, *info;
{
	*info = pvm_addmhf(*src, *tag, *ctx, foo);

}

