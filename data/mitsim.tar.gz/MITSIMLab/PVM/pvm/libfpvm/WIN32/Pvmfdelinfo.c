
/* $Id: Pvmfdelinfo.c,v 1.1 1997/06/27 16:22:37 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\src\pvmwin.h"
#endif

#include "pvm3.h"
#include "pvm_consts.h"

void __fortran
PVMFDELINFO (name_ptr, mbx_index, flags, info, name_len)
char * name_ptr; int name_len;
int *mbx_index, *flags, *info;
{

	char tname[MAX_MBOX_NAME + 1];

	/*
	*  Copy the mailbox name to make sure there is
	* a NUL at the end.
	*/
	if (ftocstr(tname, sizeof(tname), name_ptr, name_len)) {
		*info = PvmBadParam;
		return;
	}

	*info = pvm_delinfo(tname, *mbx_index, *flags);
}

