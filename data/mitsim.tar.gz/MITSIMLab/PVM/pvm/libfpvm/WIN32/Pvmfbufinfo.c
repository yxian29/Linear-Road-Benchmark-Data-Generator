
/* $Id: Pvmfbufinfo.c,v 1.1 1997/06/27 16:13:52 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\include\pvm3.h"
#include "..\..\src\pvmwin.h"
#else 
#include "pvm3.h"
#endif

#include "pvm_consts.h"

void /*__stdcall*/ __fortran
PVMBUFINFO (mid, len, type, tid, info)
int *mid, *len, *type, *tid, *info;
{
	*info = pvm_bufinfo(*mid, len, type, tid);
}

