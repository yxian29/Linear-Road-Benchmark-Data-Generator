
/* $Id: Pvmffreectx.c,v 1.1 1997/06/27 16:23:16 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\src\pvmwin.h"
#endif
#include "pvm3.h"
#include "pvm_consts.h"

void __fortran
PVMFFREECONTEXT (ctx, info)
int *ctx, *info;
{
	*info = pvm_setcontext(*ctx);
}

