
/* $Id: Pvmftidtoh.c,v 1.1 1997/06/27 16:34:41 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\include\pvm3.h"
#include "..\..\src\pvmwin.h"
#else 
#include "pvm3.h"
#endif

#include "pvm_consts.h"

void /*__stdcall*/ __fortran
PVMFTIDTOHOST (tid, dtid)
int *dtid, *tid;
{
    *dtid = pvm_tidtohost(*tid);
}

