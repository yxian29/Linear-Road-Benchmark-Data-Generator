
/* $Id: Pvmfprecv.c,v 1.1 1997/06/27 16:29:56 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\include\pvm3.h"
#include "..\..\src\pvmwin.h"
#else 
#include "pvm3.h"
#endif

#include "pvm_consts.h"

void /*__stdcall*/ __fortran
PVMFPRECV (tid, msgtag, buf,buf_len, len, dt, atid, atag, alen, info)
   int *tid, *msgtag, *len, *dt, *atid, *atag, *alen, *info;
   char *buf;int buf_len;
{
   *info = pvm_precv(*tid, *msgtag, buf, *len, *dt, atid, atag, alen);
}

