
/* $Id: Pvmfhostsync.c,v 1.1 1997/06/27 16:40:56 pvmsrc Exp $ */

#include <sys/types.h>
#ifndef WIN32
#include <sys/time.h>
#include "pvm3.h"
#else
#include "..\..\include\pvm3.h"
#include "..\..\src\pvmwin.h"
#include <time.h>
#endif


#include "pvm_consts.h"

void /*__stdcall*/ __fortran
PVMHOSTSYNC (host, sec, usec, dsec, dusec, info)
int *host, *sec, *usec, *dsec, *dusec, *info;
{
	struct timeval t, dt;

	*info = pvm_hostsync(*host, &t, &dt);
	*sec = t.tv_sec;
	*usec = t.tv_usec;
	*dsec = dt.tv_sec;
	*dusec = dt.tv_usec;
}

