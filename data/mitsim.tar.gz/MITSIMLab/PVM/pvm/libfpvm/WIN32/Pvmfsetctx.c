
/* $Id: Pvmfsetctx.c,v 1.1 1997/06/27 16:32:37 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\src\pvmwin.h"
#endif

#include "pvm3.h"
#include "pvm_consts.h"

void __fortran
PVMFSETCONTEXT (new_ctx, old_ctx)
int *new_ctx, *old_ctx;
{
	*old_ctx = pvm_setcontext(*new_ctx);
}

