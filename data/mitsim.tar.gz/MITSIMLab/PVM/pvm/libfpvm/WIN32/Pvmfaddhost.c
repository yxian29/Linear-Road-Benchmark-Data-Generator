
/* $Id: Pvmfaddhost.c,v 1.1 1997/06/27 16:13:46 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\src\pvmwin.h"
#endif
#include "pvm3.h"
#include "pvm_consts.h"

void __fortran
PVMFADDHOST (host_ptr, info, host_len)
char * host_ptr; int host_len;
int *info;
{
	int  dtid;
	char thost[MAX_HOST_NAME + 1];
	char *ptr = thost;

	/*
	 * Copy the host name to make sure there's
	 * a NUL at the end.
	 */
	if (ftocstr(thost, sizeof(thost), host_ptr, host_len)) {
		*info = PvmBadParam;
		return;
	}

	*info = pvm_addhosts(&ptr, 1, &dtid);
	if (*info >= 0)
		*info = dtid;
}

