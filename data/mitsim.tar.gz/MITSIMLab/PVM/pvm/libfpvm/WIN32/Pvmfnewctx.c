
/* $Id: Pvmfnewctx.c,v 1.1 1997/06/27 16:28:39 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\src\pvmwin.h"
#endif

#include "pvm3.h"
#include "pvm_consts.h"

void __fortran
PVMFNEWCONTEXT(ctx)
int *ctx;
{
	*ctx = pvm_newcontext();
}

