
/* $Id: Pvmfsetopt.c,v 1.1 1997/06/27 16:33:21 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\include\pvm3.h"
#include "..\..\src\pvmwin.h"
#else 
#include "pvm3.h"
#endif

#include "pvm_consts.h"

void /*__stdcall*/ __fortran
PVMFSETOPT (what, val, info)
int *what, *val, *info;
{
   *info = pvm_setopt(*what, *val);
}

