
/* $Id: Pvmfgetopt.c,v 1.1 1997/06/27 16:24:18 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\include\pvm3.h"
#include "..\..\src\pvmwin.h"
#else 
#include "pvm3.h"
#endif

#include "pvm_consts.h"

void /*__stdcall*/ __fortran
PVMFGETOPT (what, val)
int *what, *val;
{
    *val = pvm_getopt(*what);
}

