
/* $Id: Pvmfmytid.c,v 1.1 1997/06/27 16:28:37 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\include\pvm3.h"
#include "..\..\src\pvmwin.h"
#else 
#include "pvm3.h"
#endif

#include "pvm_consts.h"

void /*__stdcall*/ __fortran
PVMFMYTID (tid)
int *tid;
{
	// DebugBreak();
	*tid = pvm_mytid();
}

