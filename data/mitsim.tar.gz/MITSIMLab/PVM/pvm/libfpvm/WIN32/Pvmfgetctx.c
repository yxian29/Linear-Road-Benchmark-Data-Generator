
/* $Id: Pvmfgetctx.c,v 1.1 1997/06/27 16:24:15 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\src\pvmwin.h"
#endif
#include "pvm3.h"
#include "pvm_consts.h"

void __fortran
PVMFGETCONTEXT (ctx)
int *ctx;
{
	*ctx = pvm_getcontext();
}

