
/* $Id: Pvmfreduce.c,v 1.1 1997/06/27 16:30:33 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\include\pvm3.h"
#include "..\..\src\pvmwin.h"
#else 
#include "pvm3.h"
#endif

#include "pvm_consts.h"

#ifdef __WATCOMC__
#include "watforstr.h"
void __fortran
PVMFREDUCE (func, data,count, datatype, msgtag, gname_str, rootinst, info)
void (*func)();
void *data;
int *count, *datatype, *msgtag, *rootinst, *info;
WatcomFortranStr* gname_str;
{
   char* gname_ptr = gname_str->strP;
   int   gname_len = gname_str->len;
#else
void __stdcall
PVMFREDUCE (func, data,count, datatype, msgtag, gname_ptr,gname_len, rootinst, info)
#ifdef UXPM
void (**func)(); /* correction for Fujitsu FORTRAN77 EX */
#else
void (*func)();
#endif
void *data;
int *count, *datatype, *msgtag, *rootinst, *info;
char * gname_ptr; int gname_len;
{
#endif
   
  char tgroup[MAX_GRP_NAME + 1];

  /*
   * Copy the group name to make sure there's a NUL at the end.
   */
  if (ftocstr(tgroup, sizeof(tgroup), gname_ptr, gname_len)){
    *info = PvmBadParam;
    return;
    }

#ifdef UXPM
  *info = pvm_reduce(*func, data, *count, *datatype, *msgtag, tgroup, 
                     *rootinst);
#else
  *info = pvm_reduce(func, data, *count, *datatype, *msgtag, tgroup, 
                     *rootinst);
#endif

}

/* various reduction functions are defined here */

void __fortran
PVMMAX (datatype, data, work, count, info)
int *datatype;
void *data, *work;
int *count, *info;
{
  PvmMax(datatype, data, work, count, info);
}



void __fortran
PVMMIN (datatype, data, work, count, info)
int *datatype;
void *data, *work;
int *count, *info;
{
  PvmMin(datatype, data, work, count, info);
}

void __fortran
PVMSUM (datatype, data, work, count, info)
int *datatype;
void *data, *work;
int *count, *info;
{
  PvmSum(datatype, data, work, count, info);
}

void __fortran
PVMPRODUCT (datatype, data, work, count, info)
int *datatype;
void *data, *work;
int *count, *info;
{
  PvmProduct(datatype, data, work, count, info);
}
