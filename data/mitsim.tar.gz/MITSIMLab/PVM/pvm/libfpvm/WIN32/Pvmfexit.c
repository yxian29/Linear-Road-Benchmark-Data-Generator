
/* $Id: Pvmfexit.c,v 1.1 1997/06/27 16:22:40 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\include\pvm3.h"
#include "..\..\src\pvmwin.h"
#else 
#include "pvm3.h"
#endif

#include "pvm_consts.h"
void /*__stdcall*/ __fortran
PVMFEXIT (info)
int *info;
{
	*info = pvm_exit();
}
