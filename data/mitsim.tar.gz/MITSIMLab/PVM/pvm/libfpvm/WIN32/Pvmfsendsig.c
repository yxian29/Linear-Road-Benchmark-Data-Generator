
/* $Id: Pvmfsendsig.c,v 1.1 1997/06/27 16:32:36 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\include\pvm3.h"
#include "..\..\src\pvmwin.h"
#else 
#include "pvm3.h"
#endif

#include "pvm_consts.h"

void /*__stdcall*/ __fortran
PVMFSENDSIG (tid, signum, info)
int *tid, *signum, *info;
{
   *info = pvm_sendsig(*tid, *signum);
}

