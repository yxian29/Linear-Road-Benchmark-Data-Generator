
/* $Id: Pvmfinitsend.c,v 1.1 1997/06/27 16:27:02 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\include\pvm3.h"
#include "..\..\src\pvmwin.h"
#else 
#include "pvm3.h"
#endif

#include "pvm_consts.h"

void /*__stdcall*/ __fortran
PVMFINITSEND (tid, info)
int *tid, *info;
{
	*info = pvm_initsend(*tid);
}

