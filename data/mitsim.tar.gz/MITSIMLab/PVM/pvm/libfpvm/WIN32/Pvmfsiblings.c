
/* $Id: Pvmfsiblings.c,v 1.1 1997/06/27 17:05:05 pvmsrc Exp $ */

#ifdef WIN32
#include "..\..\src\pvmwin.h"
#endif
#include "pvm3.h"
#include "pvm_consts.h"

void __fortran
PVMFSIBLINGS (nsiblings, sibidx, stid)
int *nsiblings, *sibidx, *stid;
{
	static int nsib = -1;
	static int *sibs;
	if (nsib == -1)
		nsib = pvm_siblings(&sibs);

	*nsiblings = nsib;

	if (*sibidx >= 0 && *sibidx< nsib)
	{
		*stid = sibs[*sibidx];
	}
	else
		*stid = PvmNoTask;
}

