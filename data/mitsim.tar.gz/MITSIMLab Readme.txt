1.	Download MITSIMLab from the Linear Road website. 
2.	Extract MITSIMLab into a folder such as /home/username/MITSIMLab 
3.	If not already installed, install the latest version of PostgreSQL on the system and start the PostgreSQL postmaster. 
4.	Create a PostgreSQL user with PostgreSQL administration privileges-usually created using the PostgreSQL createuser command. 
		-It is recommended that the PostgreSQL username and the Linux account name under which MITSIMLab will run are the same.
5.	If not already done, run initdb to initialize a PostgreSQL database. 
6.	If not already done, run createdb to create the PostgreSQL database you will be using. 
7.	Edit the mitsim.txt file located in the MITSIMLab folder to update the proper database information. Make sure the following variables are properly set: 
		-databasename: should match the dbname in step 6. 
		-databaseuser: should match the username in step 4 
		-databasepassword: should match the password for the user in step 4. 
		-runpath: a folder where you want MITSIMLab to create all of its running files. MITSIMLab should be able to read and write to this folder. Please use the full path such as /home/username/MITSIMLab/data/ 
		-numberofexpressways: number of expressways you'd like MITSIMLab to generate. The system excepts any number starting at 0.5 incremented by 0.5. Thus the first three acceptable values are: 0.5, 1, 1.5. 
8.	Make sure that all files in MITSIMLab have execution privileges turned on in Linux. 
9.	To start MITSIMLab type in "./run files.txt" and hit enter. 
		-./run accepts a filename as its argument. The file is expected to contain all of the properties described in step 7. Otherwise, you may pass in a blank file and the default values will be used. 
		-The default file with all of the properties is called files.txt. You may rename it as you see fit, just make sure to pass the new name as an argument when starting MITSIMLab 
________________________________________
Note: MITSIMLab has approximately a 3 to 5 hour running time per expressway depending on computer speed.
