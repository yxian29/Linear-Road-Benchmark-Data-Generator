package LinearRoad;

use strict;
use Carp qw(croak confess);

use MSL::Network;

=head1 NAME

LinearRoad - Describe a MITSIMLab road network that is Linear.

=head1 SYNOPSIS

    use LinearRoad;

    my $lr = new LinearRoad($segmentCount);

=head1 METHODS

=over

=item new ($segment_count, $segment_length, $ramp_offset, $lanes, %network_parameters)

Creates a new linear road, with the specified number of segments
and the specified network parameters.

=cut

sub new {
  my $class = shift;
  my $self = {};
  bless $self, $class;

  $self->{yoffset} = -100;

  $self->{segment_count} = shift;
  $self->{segment_length} = shift;
  $self->{ramp_offset} = shift;
  $self->{ramp_yoffset} = -($self->{ramp_offset} + $self->{yoffset});
  $self->{lanes} = shift;
  my %network_parameters = @_;

  $self->{network} = MSL::Network->new(%network_parameters);

  my $road_length = $self->{segment_count}*$self->{segment_length};

  # Create first node, eastbound.
  my $node = $self->{network}->addNode('entry', 0, 0, "First Eastbound Node");
  foreach my $i (1..$self->{segment_count}) {
    my $end_type = ($i == $self->{segment_count}) ? "exit" : "intersection";
    $node = $self->addSegment($i, 'east', $node, $end_type);
  }

  # Create first node, westbound.
  $node = $self->{network}->addNode('entry', $road_length, 0, "First Westbound Node");
  foreach my $i (1..$self->{segment_count}) {
    my $end_type = ($i == $self->{segment_count}) ? "exit" : "intersection";
    $node = $self->addSegment($i, 'west', $node, $end_type);
  }

  return $self;
}

=item addSegment($segment_number, $direction, $start_node, $end_type)

Return the end node.

=cut
  
sub addSegment {
  my ($self, $seg, $direction, $start_node, $end_type) = @_;

  # The factor to apply to all the directions.
  my $df;
  if ($direction eq 'east') {
    $df = 1;
  } elsif ($direction eq 'west') {
    $df = -1;
  } else {
    croak "Direction is neither east nor west, it is $direction";
  }

  # alias
  my $n = $self->{network};

  # Segment starting at offset $X. Build the nodes.
  my $X = $start_node->X();
  my $on_start = $n->addNode('entry', $X, $df * $self->{ramp_yoffset},
			     "Onramp $direction start $seg");
  $self->{'onramp'.$direction}->[$seg] = $on_start;
  $X += $df * $self->{ramp_offset};
  my $on_end = $n->addNode('intersection', $X, $df * $self->{yoffset},
			   "Onramp $direction end $seg");
  # Space between onramp end and offramp start.
  $X += $df * ($self->{segment_length} - (2*$self->{ramp_offset}));
  my $off_start = $n->addNode('intersection', $X, $df * $self->{yoffset},
			      "Offramp $direction start $seg");
  $X += $df * $self->{ramp_offset};
  my $off_end = $n->addNode('exit', $X, $df * $self->{ramp_yoffset},
			    "Offramp $direction end $seg");
  $self->{'offramp'.$direction}->[$seg] = $off_end;
  my $end_node = $n->addNode($end_type, $X, $df * $self->{yoffset},
			     "Node $direction $seg");
    
  # Onramp and offramp
  $n->addOnramp($on_start, $on_end, 1, $direction, "Onramp $direction $seg");
  $n->addOfframp($off_start, $off_end, 1, $direction, "Offramp $direction $seg");
  # Three main highway segments.
  $n->addHighwaySegment($start_node, $on_end, $self->{lanes},
			$direction, "First subsegment $direction $seg");
  $n->addHighwaySegment($on_end, $off_start, $self->{lanes},
			$direction, "Second subsegment $direction $seg");
  $n->addHighwaySegment($off_start, $end_node, $self->{lanes},
			$direction, "Third subsegment $direction $seg");

  return $end_node;
}

=item network ()

Get the underlying MSL::Network object;

=cut

sub network {
  my $self = shift;
  return $self->{network};
}

=item countSegments ()

return the number of segments in the linear road.

=cut

sub countSegments {
  my $self = shift;
  return $self->{segment_count};
}

=item getRamp ($segment, $direction, $type)

Get the exit or entrance node for the ramp of the given type (off or
on), the given direction (east or west) at the given segment number.

=cut

sub getRamp {
  my ($self, $seg, $dir, $type) = @_;
  unless ($dir eq 'west' or $dir eq 'east') {
    croak "$dir is not a valid direction.";
  }
  unless ($type eq 'on' or $type eq 'off') {
    croak "$type is not a valid ramp type.";
  }
  #print "getRamp($seg, $dir, $type) = " . $self->{$type.'ramp'.$dir}->[$seg] . "\n";
  return $self->{$type.'ramp'.$dir}->[$seg];
}

1;
