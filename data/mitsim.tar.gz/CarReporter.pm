#####################################################################################
# Author	:	???
# Date		:	???
# Purposes	:
#	. Take datapoints in from mitsimlab (input parameter)
#	. Write processed data to a file (input parameter).
# Modified history :
#	Nga	Jun-15-2004	Add comments and documentation
#####################################################################################


package CarReporter;

use strict;
use IO::File;
use Data::Dumper;
use POSIX;
#use MSL::Network::Link;

#use Devel::Size qw(total_size);

# Constants
my $EMIT_DURATION = 30; # 30 seconds
my $LIMIT_SPEED = 100;  # 100 mph
my $xway = 0;
my $time_offset = 16;
my $CAR_OFFSET = 100;
my $ENTER_DISTANCE = 200; # 200 feet
my $EXIT_DISTANCE = 100; # 100 feet
my $SEGMENT_LENGTH = 5280; # 5280 feet / 1 mile
my $ENTER_SPEED = 10; # 10mph

my $queryid = 0;
my $cars_enter = -1;
my $accident = -1;
my $car1_id = -1;	# ID of the first accident car
my $car2_id = -1;	# ID of the second accident car
my $car_time_diff = int(rand($EMIT_DURATION));	#difference betweent the times of the 2 accident cars
my $first_done = 0;
my $end_first_done = 0;

my $accident_time = -1;
my $accident_xway = -1;
my $accident_lane = -1;
my $accident_pos = -1;
my $accident_dir = -1;
my $accident_end = -1;
my $next_accident = 0;


#my $nextAccidentCar1 = 0;
#my $nextAccidentCar2 = 0;
my $accidentTimeOffset = 30; # 30 seconds
my $accidentInfo = {};
my $accidentCount = 0;
my $hasCarsForAccidents = 0;
my $accidentHappening = 0;
my $east_bound = 0;
my $west_bound = 1;

# For some carid, tell us what state they were last in
# NEW (they are entering - allowed to have multiple tuples of these)
# DRIVING (they have entered, and not exiting)
# BACKHOME (they are gone - override mitsims "car hangs out in exit lane for more than one report")
my %lastStateForCar;

#-------------------------------------------------------------------------------

=pod

=head1 NAME

CarReporter - Take datapoints in from mitsimlab, write processed data to a file.

=head1 SYNOPSIS

    use CarReporter;

    my $cr = new CarReporter($network, $filename, $interval, @incidents)

    cr->datapoint($time, $carid, $lane, $x, $y);

=head1 METHODS

=over

=item new ($network, $filename, $interval, @incidents)

Create a car reporter for the given road network, output filename, reporting interval and list of accidents.

=over

=item $network: Network of a road system

=item $filename: Output file name of the report

=item $interval: Reporting interval

=item @incidents: List of accidents' location and time

*******************************************************************************

=back


=cut

#-------------------------------------------------------------------------------

sub new {
  my $class = shift;
  my $self = {};
  bless $self, $class;
  
  $self->{network} = shift;
  $self->{filename} = shift;
  $self->{interval} = shift;  
  my @incidents = @_;

  # Put @incidents list into $self->{incidents}
  $self->{incidents} = [];
  splice(@{$self->{incidents}}, 0, 0, @incidents);

  $self->{accidentCars} = [];  

  # IO Handle.
  $self->{output} = new IO::File;
  $self->{output}->open("> ".$self->{filename}) or die $!;

  # Debug
  $self->{output_test} = new IO::File;
  $self->{output_test}->open("> " .$self->{filename} .".debug") or die $!;

  # Map of carid-> reporting offset.
  $self->{report_offset} = {};

  # Map of carid-> array of refs to arrays. Each array is a tuple
  # (time, X, Y). Gets zeroed each time we report.
  $self->{positions} = {};

  $self->incidentsPosProcess();
  $self->nextAccident();  
  $next_accident = $accidentInfo->{startTime}; 

  #DEBUG
  $self->{output_test}->print("----------------------------------\n");
  $self->{output_test}->print("NExt accident Time: $next_accident\n");
  $self->{output_test}->print("Mitsim Lane: $accidentInfo->{laneID}\n");
  $self->{output_test}->print("Linear road lane: $accidentInfo->{linearRoadLaneID}\n");
  $self->{output_test}->print("Duration: $accidentInfo->{duration}\n");
  $self->{output_test}->print("Position: $accidentInfo->{gx}\n");
  $self->{output_test}->print("----------------------------------\n");

  return $self;
}

#-------------------------------------------------------------------------------
# Show incidents
# Debug method

sub showIncidents
{
   my $self = shift;
   
   my $incidentCount = scalar @{$self->{incidents}};
 
   print "INCIDENTS: -----------------\n";
   print "Incidents count: $incidentCount\n";

   for (my $i = 0; $i < $incidentCount; $i++)
   {
      print "Linear Road lane ID : $self->{incidents}[$i]->{linearRoadLaneID}\n";
      print "Start Time : $self->{incidents}[$i]->{startTime} \n";
      print "Duration : $self->{incidents}[$i]->{duration} \n";
      print "Direction : $self->{incidents}[$i]->{direction}\n";
      print "Gobal coordiation X : $self->{incidents}[$i]->{gx} \n";
      print "Gobal coordiation Y : $self->{incidents}[$i]->{gy} \n";
      print "Mitsim laneD : $self->{incidents}[$i]->{laneID} \n";
      print "Mitsim  segment ID : $self->{incidents}[$i]->{segmentID} \n";
      print "Mitsim  endPosition : $self->{incidents}[$i]->{endPosition}\n";

   }   
   print "----------------------------\n";
}

#-------------------------------------------------------------------------------
# Internal method
# Call: nextAccident()
# Get information of next accident and store it to $accidentInfo

sub nextAccident
{
   my $self = shift;
  
   $accidentInfo = shift @{$self->{incidents}};
   $accidentCount--;
}

#-------------------------------------------------------------------------------
# Internal method
# Call: incidentsPosProcess()
# Transfer:
#	. Local position to global position
#	. MITSIM lane ID to Linear Road lane ID

sub incidentsPosProcess
{
   my $self = shift;

   $accidentCount = scalar @{$self->{incidents}};

   for (my $i = 0; $i < $accidentCount; $i++)
   {
      # Get global position
      my $link = $self->{network}->findLane($self->{incidents}[$i]->{laneID});

      ($self->{incidents}[$i]->{gx}, $self->{incidents}[$i]->{gy}) = 
          $link->linkXYToGlobalXY($self->{incidents}[$i]->{endPosition}, 0);

      # Get direction
      $self->{incidents}[$i]->{direction} = $link->{direction}; 

      # Get Linear Road lane ID
      # Transfer MITSIM lane ID to Linear Road ID: 1, 2, 3 (Only main lane, no entry, no exit)
      #Lanes are number 1 to N.
      my $laneId;
      my @lanes = $link->lanes();
      my $laneCount = scalar @lanes;
      for (my $j = 0; $j < $laneCount; $j++)
      {
         if ($lanes[$j] == $self->{incidents}[$i]->{laneID})
         {
  	    $laneId = $j + 1;
	    last;
  	  }
      }

      $self->{incidents}[$i]->{linearRoadLaneID} = $laneId;
   }
}


#-------------------------------------------------------------------------------
# Internal method
# Call:	$x = isAccidentCar($carid, $time)
# Check whether the input $carid has been choosen as an accident car before $time
# Return:
# 	. 1 : true
#	. 0 : false

sub isAccidentCar
{
   my $self = shift;
   my $carid = shift;
   my $time = shift;

   my $count = scalar @{$self->{accidentCars}};
   for ( my $i = 0; $i < $count; $i++)
   {
       if ( ($carid == $self->{accidentCars}[$i]->{carid}) &&
            ($time >= $self->{accidentCars}[$i]->{accidentTime})
          )
        {
           # This car has been choosen as an accident car
           return 1;
        } 
   }

   # Car is not the accident car
   return 0;
}


#-------------------------------------------------------------------------------
# write accident cars into a test file (temporary file)
# Debug method

sub accidentCars
{
   my $self = shift;
 
   my $count = scalar @{$self->{accidentCars}};

   $self->{output_test}->print("\n\nAccident cars -------------------------\n");      

   for ( my $i = 0; $i < $count; $i++)
   {
       $self->{output_test}->print("Car ID: $self->{accidentCars}[$i]->{carid}");
       $self->{output_test}->print("- Time: $self->{accidentCars}[$i]->{accidentTime}\n"); 
   }
   $self->{output_test}->print("------------------------------------\n");
}


#-------------------------------------------------------------------------------
# write accident cars to STOUT
# Debug method

sub showAccidentCars
{
   my $self = shift;
 
   my $count = scalar @{$self->{accidentCars}};
  print "\n\nAccident cars -------------------------\n";

   for ( my $i = 0; $i < $count; $i++)
   {
       print "Car ID: $self->{accidentCars}[$i]->{carid} - Time: $self->{accidentCars}[$i]->{accidentTime}\n"; 
   }
   print "------------------------------------\n";
}


#-------------------------------------------------------------------------------
# ...

sub record_position {
  my ($self, $carid, $time, $x, $y) = @_;
  unless (exists $self->{positions}->{$carid}) {
    $self->{positions}->{$carid} = [];
  }
  my @tuple = ($time, $x, $y);
  push @{$self->{positions}->{$carid}}, \@tuple;
}


#-------------------------------------------------------------------------------
# ...

sub clear_positions {
  my ($self, $carid) = @_;
  $self->{positions}->{$carid} = [];
}


#-------------------------------------------------------------------------------
# ...

sub distance {
  my ($ox, $oy, $nx, $ny) = @_;
  return (($nx - $ox)**2 + ($ny - $oy)**2)**.5;
}


#-------------------------------------------------------------------------------
# ...

sub get_average_speed {
  my ($self, $carid) = @_;
  my @points = @{$self->{positions}->{$carid}};
  #print "get_average_speed of $carid data points: ", Dumper(\@points);
  if (scalar @points == 0) {
    die "tried to get average speed, with no points";
  }
  # Pull off the first point to see the old values.
  my $ref = shift @points;
  my ($ot,$ox,$oy) = @$ref;
  my ($nt,$nx,$ny);
  my ($total, $count) = (0,0);
  foreach $ref (@points) {
    ($nt, $nx, $ny) = @$ref;
    #print "ot, ox, oy = ($ot, $ox, $oy); nt, nx, ny = ($nt, $nx, $ny)\n";
    # Feet per second.
    my $speed = distance($ox, $oy, $nx, $ny) / ($nt - $ot);
    # Change to miles per hour.
    $speed = $speed * (3600.0/$SEGMENT_LENGTH);
    if ($speed > $LIMIT_SPEED) {
	print "carid $carid: One-second speed $speed\n";
	print "carid $carid: Between ($ot, $ox, $oy) and ($nt, $nx, $ny)\n";
    }
    # Record it in the running total:
    $total += $speed;
    $count++;
    # Next datapoint.
    ($ot, $ox, $oy) = ($nt, $nx, $ny);
  }
  return $total/$count;
}


#-------------------------------------------------------------------------------


=pod

=item datapoint($time, $carid, $laneid, $lx, $ly)

Take a datapoint with the following data, record the data, and
possibly write a processed data point out to a file.

=over

=item $time: The time in seconds of the car.

=item $carid: The id of the car in question.

=item $laneid: The lane the car is in (MITSIM lane ID).

=item $lx: The local x coordinate of the car.

=item $ly: The local y coordinate of the car.

=back

Format of the processed data:
   (type, time, carid, speed, xway, lane, dir, seg, pos, queryid, m_init, m_end, dow, tod, day)

=cut

#-------------------------------------------------------------------------------

sub datapoint {
  my ($self, $time, $carid, $laneid, $lx, $ly) = @_;

  $self->printsize("Start of datapoint");

  # If we don't have a report offset for this id yet, make this first report
  # the offset.
  unless (exists $self->{report_offset}->{$carid}) {
    #print "Setting offset fo car $carid to ", ($time+15) % 30, ".\n";
    $self->{report_offset}->{$carid} = ($time+15) % 30;
  }
  
  # Look up the lane.
  my $link = $self->{network}->findLane($laneid);
	# DEBUG
	#   print "carid $carid: On link ", $link->description(), " from (",
	# 	$link->start()->X(), ", ", $link->start()->Y(), ") to (",
	# 	$link->end()->X(), ", ", $link->end()->Y(), ").\n";
	#   print "carid $carid: at relative position $lx, $ly\n";

  # Get the global x and y.
  my ($gx, $gy) = $link->linkXYToGlobalXY($lx, $ly);
	# DEBUG
	#  print "carid $carid: at global position $gx, $gy\n";
    
  # Record a data point.
  $self->record_position($carid, $time, $gx, $gy);
  
  # Report only if the offset on the current report matches this
  # cars report offset
  if ($self->{report_offset}->{$carid} == $time % 30) {

    # Figure out which lane we are in.
    # $laneid is the id of MITSIM, we need our ID: 0..4 (3 lanes + entry and exit)
    my $laneNum;
    if ($link->type() == 1) {
      # Ramp.
      $laneNum = 0;
    } else {
      # Not a ramp. Lanes are number 1 to N.
      my @lanes = $link->lanes();
      for (my $i = 0; $i < @lanes; $i++) {
	if ($lanes[$i] eq $laneid) {
	  $laneNum = $i + 1;
	  last;
	}
      }
    }


    my $status;
    # Figure out the true state of things
    if (!defined $lastStateForCar{$carid}) { # Never seen this guy - you must be on entrance lane, and new
	$status = "ENTRANCELANE";
	$lastStateForCar{$carid} = "NEW";
    } elsif ($laneNum == 0 && $lastStateForCar{$carid} eq "NEW") { # You are still new, so still in entrance lane
	$status = "ENTRANCELANE";
    } elsif ($laneNum == 0 && $lastStateForCar{$carid} eq "DRIVING") { # You were driving before and thus you are exiting
	$status = "EXITLANE";
	$lastStateForCar{$carid} = "BACKHOME"; # You are exiting, you get home right away
    } elsif ($lastStateForCar{$carid} eq "BACKHOME") { # You exited already. I dont want your extra data point
	$status = "IGNORE";
    } else { # Well, gotta be driving then!
	$status = "TRAVELLANE";
	$lastStateForCar{$carid} = "DRIVING";
    }

    # If BACKHOME, status is IGNORE and we can ignore the car and not worry 
    # generating the tuple
    if ($status eq "EXITLANE") {
	$laneNum = 4;
    } elsif ($status eq "IGNORE") {
	return;
    }

    # Get our average speed, and zero it.
    $self->printsize("Before clearing positions");
    my $speed = $self->get_average_speed($carid);
    if ($speed > $LIMIT_SPEED) {
	print "carid $carid: ERROR: Speed greater than $LIMIT_SPEED ($speed) detected.\n";
	print "carid $carid: at $time seconds on link ", $link->description(), ".\n";
    }
    $self->clear_positions($carid);
    $self->printsize("After clearing positions");
    
    my $tuple;  

    #............................................................................................
    # schema
    # (type, time, carid, speed, xway, lane, dir, seg, pos, queryid, m_init, m_end, dow, tod, day)
    #............................................................................................

    $carid = $carid + $CAR_OFFSET;


    # Look for 2 cars going nearby the accident location

    if ( !$accidentHappening &&
         ( ($car1_id == -1) || ($car2_id == -1) ) &&
         ( ($time - $time_offset) < $next_accident) &&
         ( ($time - $time_offset) >= ($next_accident - $accidentTimeOffset) )&&
         ( $laneid == $accidentInfo->{laneID}) &&
         ( ( ($accidentInfo->{direction} == $east_bound) && 
             (($accidentInfo->{gx} - $gx) > (($next_accident - ($time - $time_offset) ) * $speed) ) )
           || 
           ( ($accidentInfo->{direction} == $west_bound) && 
             (($gx - $accidentInfo->{gx}) > (($next_accident - ($time - $time_offset) ) * $speed) ) )
         )  
       )
    {
       
        
       if ($car1_id == -1) {
           $car1_id = $carid;
           $accident_pos = floor($accidentInfo->{gx});
 
#          $nextAccidentCar1 = $next_accident + $EMIT_DURATION - (($next_accident - $time - $time_offset)%$EMIT_DURATION);           
#          $accident_pos = $gx;
       } else {
           $car2_id = $carid;
           $hasCarsForAccidents = 1;

#           $nextAccidentCar2 = $next_accident + $EMIT_DURATION - (($next_accident - $time - $time_offset)%$EMIT_DURATION);
#           if ($nextAccidentCar1 <= $nextAccidentCar2) {
#               # Car 1 reaches the acciddent location first
#               $next_accident = $nextAccidentCar1;
#               $car_time_diff = $nextAccidentCar2 - $next_accident;                
#           } else {
#               # Car 2 reaches the acciddent location first  -> Change car 2 to car 1
#               my $carTmp = $car1_id;
#               $car1_id =  $car2_id;
#               $car2_id =  $carTmp; 
#               $next_accident = $nextAccidentCar2;
#               $car_time_diff = $nextAccidentCar1 - $next_accident;
#               $accident_pos = $gx;
#           } 

           $self->{output_test}->print( "Car in the accident lane\n");   
           $self->{output_test}->print( "   Car1_id: $car1_id\n");
           $self->{output_test}->print( "   Car2_id: $car2_id\n");
       }         
    }



    # ....................................................................................
    # USUAL PART - INPUTS FROM CARS 
    # Position reports

    if (!$self->isAccidentCar($carid, $time - $time_offset))
    {
        $tuple = join(",",
		  0,				# Type = 0: Position reports
                  $time - $time_offset,		# Timestamp the position report was emitted (seconds)
                  $carid,			# vehicle ID
                  int($speed+.5),		# Speed: MPH
		  $xway,			# Expressway ID, always 0
                  $laneNum,			# Lane ID
                  $link->direction(),		# Direction (west, east)
                  floor(int($gx+.5) / $SEGMENT_LENGTH),	# Mile-lomg segment
                  int($gx+.5),			# Position: feet
                  -1, -1, -1, -1, -1, -1);	# unused data

        $self->{output}->print($tuple, "\n");	# write tuple into the output file
    }

    # ....................................................................................
    # HISTORICAL QUERY REQUESTS.
    # Only 1% of emitted position reports are accompanied by these.
    # Among these requests: 
    #	. 50% CHANCE OF TYPE 2
    #	. 10% CHANCE OF DAILY EXPENDITURE
    #	. 40% CHANGE OF TRAVEL TIME

    my $num = int(rand(99) + 1);	# num between 1 and 100
        
    if ($num == 1) {			# Only 1%
	$num = int(rand(99) + 1);
	if ($num <= 50) {

	    # 50% for account balance, type = 2

	    $tuple = join(",",
			  2,
                         $time - $time_offset,
                         $carid,
                         -1, -1, -1, -1, -1, -1,
                         $queryid,
                         -1, -1, -1, -1, -1);
	} elsif ($num <= 60) {

	    # 10% for daily expenditure, type = 3

	    $tuple = join(",",
			  3,
                          $time - $time_offset,
                          $carid,
                          -1,
                          $xway,
                          -1, -1, -1, -1,
                          $queryid,
                          -1, -1, -1, -1,
                          int(rand(70)));	# Day: 1: yesterday, 69: 10 weeks ago
	} else {		

	    # 40% for travel time, type = 4;

	    $tuple = join(",",
			  4,
                          $time - $time_offset,
                          $carid, -1,
                          $xway,
                          -1, -1, -1, -1,
                          $queryid,
                          0,	# Init segment (why 0 ???)
                          0, 	# End segment  (why 0 ???)
                          0,	# Day of week: 1..7  (why 0 ???)
                          0,	# Minute number in the day when the journey would take place: 1..1440  (why 0 ???)
                          -1); 
	}

	$queryid++;

	$self->{output}->print($tuple, "\n");
    }
    
    # ....................................................................................
    # ACCIDENTS

    if ( (($time - $time_offset) == $next_accident)
         && !$accidentHappening ) 
    {
      
       $accidentHappening = 1;  
       $accident_xway = $xway;
       $accident_dir = $accidentInfo->{direction};
       $accident_time = $time - $time_offset;
       # End time must be at least 1 second before next accident starts
       $accident_end = $accident_time + $accidentInfo->{duration} - $car_time_diff - 1;  

        if ($hasCarsForAccidents) {
           # Two running cars cause the accident
           $cars_enter = 1;

           # Store 2 cars into the accident list
           my $accidentCar1 = {};
           my $accidentCar2 = {};

           $accidentCar1->{carid} = $car1_id;
           $accidentCar1->{accidentTime} = $next_accident;
           push @{$self->{accidentCars}}, $accidentCar1;

           $accidentCar2->{carid} = $car2_id;
           $accidentCar2->{accidentTime} = $next_accident;
           push @{$self->{accidentCars}}, $accidentCar2;

        } else {
           # No cars running at the accident location --> creat them
           $accident = 0;
   	   $cars_enter = 0;
        }
    }

    if ($accident == 0 && $cars_enter == 0) {  # if no accidents out there, make one
         # No cars running at the accident site --> creat them	
		
        # first car gives the very first tuple
        # The first car enters the express way 
	if ($first_done == 0) {

            $car1_id = int(rand(99) + 1);

            # The entered position is $ENTER_DISTANCE feet from the accident's position
	    $accident_pos =
			floor($accidentInfo->{gx}) - 
			$ENTER_DISTANCE + 
			(2 * $accident_dir * $ENTER_DISTANCE);

            if ($accident_pos < 0) {
               $accident_pos = 0;
            }

	    $tuple = join(",",
			  0,
                          $accident_time,
                          $car1_id,
                          int($speed+.5),
                          $accident_xway,
                          0, 				# Always at lane 0 (entry) 
			  $accident_dir,
                          floor($accident_pos/$SEGMENT_LENGTH),
                          $accident_pos,
                          -1, -1, -1, -1, -1, -1);

	    $self->{output}->print($tuple, "\n");
            
            #DEBUG
 	    $self->{output_test}->print($tuple, "\n");  

	    $first_done = 1;
	}
	
        # second car gives its first
        # The second car enters the express way 
	if (($time - $time_offset) == ($car_time_diff + $accident_time)) {
            do {
               $car2_id = int(rand(99) + 1);
            } until ($car2_id != $car1_id);

	    $tuple = join(",",
			  0,
                          $time - $time_offset,
                          $car2_id,
                          int($speed+.5) + $ENTER_SPEED,# Speed
                          $accident_xway,
                          0, 				# Always at lane 0 (entry) 
			  $accident_dir,
                          floor($accident_pos/$SEGMENT_LENGTH),
                          $accident_pos - 20,
                          -1, -1, -1, -1, -1, -1);

	    $self->{output}->print($tuple, "\n");
           
            # DEBUG
	    $self->{output_test}->print($tuple, "\n");  

	    $first_done = 0;
	    
	    # .............................................................
            # the two cars have entered and they are going to DIE (accident)

	    $cars_enter = 1;
	    $accident_time = $accident_time + $EMIT_DURATION;
	    $accident_pos =
			$accident_pos + $ENTER_DISTANCE - 
			(2 * $accident_dir * $ENTER_DISTANCE);

            if ($accident_pos < 0) {
               $accident_pos = 0;
            }	        
	}
    }
    elsif ( $cars_enter == 1 ) {  # cars in the highway  
  
            # vehicle went a distance from the accident
            # if $accident_dir = 0: Eastbound -> position increases $EXIT_DISTANCE feet
            # if $accident_dir = 1: Westbound -> position decrease $EXIT_DISTANCE feet
            # Exit segment must be in the accident segment

  	    my $accidentSegment =  floor($accident_pos/$SEGMENT_LENGTH);
            my $distance = $EXIT_DISTANCE - (2 * $accident_dir * $EXIT_DISTANCE);

	    if ( floor(($accident_pos + $distance)/$SEGMENT_LENGTH)  != $accidentSegment) {
		$distance = 0 - $distance;
            }

            my $position = $accident_pos + $distance;
            if ($position < 0) {
               $position = 0;
            }

        # The first car out
       	if ( ( ($time - $time_offset) == $accident_end) && 
             ($end_first_done == 0) ) {     
 
            $tuple = join(",",
			  0,
                          $time - $time_offset,
                          $car1_id,
                          $ENTER_SPEED,		# out speed
                          $accident_xway,
                          4, 			# Exit Lane
			  $accident_dir,
                          floor($position/$SEGMENT_LENGTH),
                          $position, 
                         -1, -1, -1, -1, -1, -1);

	    $self->{output}->print($tuple, "\n");
            # DEBUG
	    $self->{output_test}->print($tuple, "\n");  

	    $end_first_done = 1; 

            
            if ($accidentCount > 0) {
               $self->nextAccident();
               $next_accident = $accidentInfo->{startTime};

                #DEBUG
		$self->{output_test}->print("----------------------------------\n");
		$self->{output_test}->print("NExt accident Time: $next_accident\n");
		$self->{output_test}->print("Mitsim Lane: $accidentInfo->{laneID}\n");
		$self->{output_test}->print("Linear road lane: $accidentInfo->{linearRoadLaneID}\n");
		$self->{output_test}->print("Duration: $accidentInfo->{duration}\n");
		$self->{output_test}->print("Position: $accidentInfo->{gx}\n");
		$self->{output_test}->print("----------------------------------\n");

            } else {
               $next_accident = 0;
            }
	}
	
         # The second car out
	if (($time - $time_offset) == ($accident_end + $car_time_diff)) {
	    $tuple = join(",",
			  0,
                          $time - $time_offset,
                          $car2_id,
                          $ENTER_SPEED,	# out spped
                          $accident_xway,
                          4, 
			  $accident_dir,
                          floor($position/$SEGMENT_LENGTH),
                          $position,
                         -1, -1, -1, -1, -1, -1);

	    $self->{output}->print($tuple, "\n");
            # DEBUG
	    $self->{output_test}->print($tuple, "\n");  
	    
	    $cars_enter = 0;
	    $car1_id = -1;
	    $car2_id = -1;
	    $end_first_done = 0;
	    $car_time_diff = int(rand($EMIT_DURATION));
	    $accident_time = -1;
	    $accidentHappening = 0;
            $hasCarsForAccidents = 0; 
	}
    }

    # Accident occurs 
    if ( (($time - $time_offset) == $accident_time && $first_done == 0)
         && $accidentHappening  && !$end_first_done
	)
    {
	$tuple = join(",",
		      0,
                      $accident_time,
                      $car1_id,
                      0,					# Accident -> speed = 0
                      $accident_xway,
                      $accidentInfo->{linearRoadLaneID},
		      $accident_dir,
                      floor($accident_pos/$SEGMENT_LENGTH),	# Accident -> Same segment
                      $accident_pos,				# Accident -> Same position
                      -1, -1, -1, -1, -1, -1);

	$self->{output}->print($tuple, "\n");
        # DEBUG
        $self->{output_test}->print($tuple, "\n");  

	$first_done = 1;
    }
    
    if ( (($time - $time_offset) == ($car_time_diff + $accident_time))
         && $accidentHappening
       )
    {

	$tuple = join(",",
		      0,
                      $time - $time_offset,
                      $car2_id,
                      0,					# Accident -> speed = 0
                      $accident_xway,
                      $accidentInfo->{linearRoadLaneID},, 
		      $accident_dir,
                      floor($accident_pos/$SEGMENT_LENGTH),	# Accident -> Same segment
                      $accident_pos,				# Accident -> Same position
                      -1, -1, -1, -1, -1, -1);

	$self->{output}->print($tuple, "\n");
        # DEBUG
        $self->{output_test}->print($tuple, "\n");  

	$accident = 1;
	$accident_time = $accident_time + $EMIT_DURATION;
	$first_done = 0;
    }
}


}


#-----------------------------

sub printsize {
  #my $self = shift;
  #print @_, "\n";
  #my $positions = total_size($self->{positions});
  #print "Total size of postions: ", $positions, "\n";
  #print "Size of rest of CarReporter: ", total_size($self) - $positions, "\n";
  #print "---\n";
}
1;
