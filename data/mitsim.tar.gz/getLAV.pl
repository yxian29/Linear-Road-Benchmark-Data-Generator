#!/usr/bin/perl -w

# Given time (minute) of the "segment statistic" record - segment no - direction -
# it tells you the LAV at that stat record place, moment, direction. I.e. the LAV
# that would be sent for toll alerts to cars in time (minute+1) on this segment/direction.
#   Time must be >= 5



if (@ARGV != 3) { die ("Usage: getLAV.pl [minute (of stat record)] [segment] [direction] < [INPUT FILE]"); }

my ($minute, $segment, $direction) = (@ARGV);

$minute >= 5 or die ("Invalid minute - please start at 5");
$segment >= 0 and $segment < 100 or die ("Invalid segment");
$direction == 0 || $direction == 1 || die("Invalid direction");


my $pstart = ($segment * 5280);
my $plast = ($segment * 5280) + 5280 - 1;

my $tstart = ($minute - 5 + 1) * 60 - 60;
my $tlast = ($minute - 1 + 1) * 60 - 1;

# print "min $minute (lav stats for sec $tstart to $tlast) seg $segment (pos $pstart to $plast) and dir $direction\n";

sub secToMin {
    my ($s) = @_;
    return int((($s / 60) + 1));
}



my %myhash = ();

print "(Reading from STDIN...)\n";
while (<STDIN>) {

    my ($type,$time,$carid,$speed,$xway,$lane,$dir,$seg,$pos,$qid,$mstart,$mend,$dow,$tod,$day) =
	(/(\d+),(\d+),(\d+),(\d+),(\d+),(\d+),(\d+),(\d+),(\d+),(-?\d+),(-?\d+),(-?\d+),(-?\d+),(-?\d+),(-?\d+)/) or next;
    
    if (secToMin($time) > $minute) { last; }

    if ($time < $tstart || $time > $tlast || $pos < $pstart || $pos > $plast || $dir != $direction) { next; }
    
    if (defined($myhash{secToMin($time)}{$carid})) {
	my $sp = $myhash{secToMin($time)}{$carid};
	$myhash{secToMin($time)}{$carid} = (($sp + $speed) / 2.0); # u can do that cuz at most theres only one dupe
    } else {
	$myhash{secToMin($time)}{$carid} = $speed;
    }

}


my $totspeed_total = 0; # used for lav
my $lastcount = 0;
my $lastavspeed = -1;

my $num_mins_in_calc = 0;

while (my ($min,$h) = each(%myhash)) {

    ++$num_mins_in_calc;

    my $totspeed = 0;
    my $carcount = 0;
    my $avspeed = -1;
#    print "MINUTE [$min]:\n";
    while (my ($car,$sp) = each(%$h)) {
#    print "     CAR [$car] - SPEED [$sp]\n";
	++$carcount;
	$totspeed += $sp;
    }
    $avspeed = $totspeed / $carcount;
    if ($min == $minute)
    { $lastcount = $carcount; $lastavspeed = $avspeed }  #if this is the last minute, info that goes in the stat record...

#    print " CAR COUNT IS $carcount AND AVSPEED IS $avspeed\n";

    $totspeed_total += $avspeed;
}

my $lav;
if ($num_mins_in_calc == 0) { $lav = -1; } # No data points, defines a "null" LAV (-1)
                                           # (IOTW LAV(-1,-1,-1,-1,-1) = -1) [LAV(avspeed_min_t-4, etc)]
else { $lav = int($totspeed_total / $num_mins_in_calc); }

print "\nLAV:$lav\nCARCOUNT OF GIVEN MIN:$lastcount\nAVG SPEED OF GIVEN MIN:$lastavspeed\n";
